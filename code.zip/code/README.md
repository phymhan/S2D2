# S2D2: Fast Decoding for Block-Diffusion LLMs via Training-Free Self-Speculation

## Installation

Please follow each model's official instructions to install required packages.

- **SDAR** requires `transformers==4.52.4` and:
  ```bash
  pip install "flash-attn==2.7.4.post1" --no-build-isolation --no-cache-dir
  ```

## Usage

### SDAR

```bash
cd SDAR
python generate.py                        # standard diffusion decoding
python generate_ssd_policy.py             # S2D2 (ours)
python generate_ssd_policy.py --draft_ver --cache_ver  # with AR-like caching
```

### Fast-dLLM-v2

```bash
cd Fast-dLLM-v2
python example_v2.py --generate_fn='fast'        # standard diffusion decoding
python example_v2.py --generate_fn='ssd_policy'  # S2D2 (ours)
```

### LLaDA2.x

```bash
cd LLaDA2
python example_llada.py --generate_fn='nocache'     # no-cache version (from model card)
python example_llada.py --generate_fn='cached'       # KV-cached decoding (ours)
python example_llada.py --generate_fn='ssd_policy'   # S2D2 (ours)
```

## Routing Policies

| Argument | Description |
|---|---|
| `--do_verify_policy` | `mask_span_length`, `score_threshold`, `score_hysteresis`, `contextual_bandit_ucb` |
| `--do_verify_score_threshold` | Score threshold |
| `--hysteresis_threshold_on` / `--hysteresis_threshold_off` | Hysteresis thresholds |
| `--do_verify_score_type` | `difference_static` or `difference_dynamic` |
| `--score_penalty_coef` | Penalty coefficient |
| `--token_acceptance_estimator` | `soft_entropy_negexp` or `hard_margin_threshold` |
